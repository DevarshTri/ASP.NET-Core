﻿namespace STORE_DataTransfer.Models
{
    public interface IDataTransferService
    {
        Task TransferDataAsync();
    }
}
